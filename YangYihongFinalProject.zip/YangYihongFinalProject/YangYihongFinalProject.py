"""
YangYihongFinalProject.py
The meal order system in hospital.
"""
import tkinter as tk   # access to tkinter module and name it as tk
from tkinter import Toplevel, ttk   # Toplevel for creating windows, ttk
from tkinter.ttk import *
import time
from datetime import datetime, date  # for detect date and time
from PIL import Image, ImageTk    # for adding images
import tkinter.messagebox      # for use of messagebox
import pickle        # for store a dictionaty to a file, and read a *pkl file


class Welcome(tk.Tk):
    """Main window."""
    def __init__(self):
        super().__init__()        
        self.title("ABH Hospital Online Meal Order Service")  # name the window
        self.configure(bg="light blue")    # set the color of background    
        self.geometry("800x790+50+50") # sets the size of main root window      
        self.createWidget()

    def createWidget(self):
        """Create widgets"""
        # creates a Text widget
        self.welcome = tk.Text(self, width=100, height=1, bg="light blue", \
            font=("times new man",30))  # set size and color and font size
        self.welcome.pack()    # place in the center
        self.welcome.insert(1.5,"Welcome to ABH Hospital meal order page.")  # insert a sentence.

        # insert a photo to mainwindow
        self.photo = tk.PhotoImage(file="hospital.gif")  # pick the image
        self.imagLabel = Label(self, image=self.photo)   # create a image label
        self.imagLabel.pack()       # put it in the center             
 
        # text field for information
        self.introduction = tk.Text(self, width=100, height=6, bg="light blue", \
            font=("times new man",20))
        self.introduction.pack() 
        self.introduction.insert(1.0, "You may order your breakfast, lunch and diner.\n"+
                            "Easy click to choose your today meal.\n"+
                            "Order Time: \n"+
                            "Breakfast      Before 7am (7:00)\n"+
                            "Lunch           Before 11am (11:00)\n"+
                            "Dinner          Before 5pm (17:00)") 
        # creat a command button
        self.btn = Button(self, text ="Ready for Your Order", command=self.btnState) # click this button and active a function
        self.btn.pack(side=tk.BOTTOM, pady = 10)  # place at the bottom, pady: for set space between widgets
 
        
    def btnState(self):
        """a button widget which will open a new window on button \
            click, and disable "btn" Button """
        self.btn["state"] = "disabled"  # make the button inactive
        newWindow = MealOrder(self)    # 2nd window
        newWindow.grab_set()

    def btnEnableState(self, event):
        """Function for reactiving a button"""
        self.btn["state"] = "normal"    # make a disabled button be normal


class MealOrder(tk.Toplevel):
    """This is the second window for order meal"""   
    
    def __init__(self, master=None):
        super().__init__(master, bg="light blue")
        self.master = master
        self.title("Meal Order Page")  # name the window
        self.geometry("800x800+700+30") # set the window size
        self.createWidget()
        self.orders = {}   # make a empty dictionaty to store meal information: key=food, value=price
        self.orderTime()   
    

    def createWidget(self):
        """create widget"""
        # change the color of bg of label
        style = ttk.Style()
        style.configure("BG.TLabel", foreground="black", background="light blue")
        style.configure("BG.TCheckbutton", foreground="black", background="light blue")
        style.configure("BG.TButton", foreground="black", background="light blue")
        # Create label of "Meal Order"
        self.label = Label(self, text ="Meal Order", font=("times new man", 20), style="BG.TLabel")
        self.label.pack()        

        # build "Breakfast" label
        self.breakLabel = Label(self, text="Breakfast", font=("times new man", 16), style="BG.TLabel")
        self.breakLabel.place(relx=0.03, rely=0.05)
        
        # Three Checkbuttons for breakfast(milk, soup, bread), place them at their locations.
        self.milk = tkinter.IntVar()   # self.milk is int variable
        self.soup = tkinter.IntVar()
        self.bread = tkinter.IntVar()

        self.milkCheck = Checkbutton(self, text="Milk", variable=self.milk, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton", \
                                    state = "normal")  # name, set value to the Checkbutton
        self.soupCheck = Checkbutton(self, text="Soup", variable=self.soup, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton", \
                                    state = "normal")
        self.breadCheck = Checkbutton(self, text="Bread", variable=self.bread, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")
        self.milkCheck.place(relx=0.25, rely=0.055)  # relx, rely : set location of checkbutton using (0.0, 1.0)
        self.soupCheck.place(relx=0.5, rely=0.055)
        self.breadCheck.place(relx=0.75, rely=0.055)

        # "Visit", "Place Order" and "Exit" buttons
        self.visitBtn = Button(self, text="Visit Order", command=self.mealVisit, style="BG.TButton")
        self.visitBtn.place(relx=0.25, rely=0.95)
        self.orderBtn= Button(self, text="Place Order", command=self.openWindow, style="BG.TButton" )
        self.orderBtn.place(relx=0.45, rely=0.95)
        self.exitBtn = Button(self, text="Exit", command=self.destroy, style="BG.TButton")
        self.exitBtn.place(relx=0.65, rely=0.95)

        self.exitBtn.bind("<Destroy>", self.master.btnEnableState)  # Event: Click exitBtn and active continue button.     
    
        # build "Lunch" label
        self.lunLabel = Label(self, text="Lunch", font=("times new man", 16), style="BG.TLabel")
        self.lunLabel.place(relx=0.03, rely=0.35)

        # Three Checkbuttons for lunch(juice, chicken, beef)
        self.juice = tkinter.IntVar()
        self.chicken = tkinter.IntVar()
        self.beef = tkinter.IntVar()

        self.juiceCheck = Checkbutton(self, text="Juice", variable=self.juice, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")   
        self.chickCheck = Checkbutton(self, text="Chicken", variable=self.chicken, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")
        self.beefCheck = Checkbutton(self, text="Beef", variable=self.beef, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton", \
                                    state = "normal")
        self.juiceCheck.place(relx=0.25, rely=0.355)
        self.chickCheck.place(relx=0.5, rely=0.355)
        self.beefCheck.place(relx=0.75, rely=0.355)        

        # build "Dinner" label
        self.dinnerLabel = Label(self, text="Dinner", font=("times new man", 16), style="BG.TLabel")
        self.dinnerLabel.place(relx=0.03, rely=0.65)

        # Three Checkbuttons for dinner(milk, salad, pizza)
        self.milk2 = tkinter.IntVar()
        self.salad = tkinter.IntVar()
        self.pizza = tkinter.IntVar()

        self.milkCheck2 = Checkbutton(self, text="Night milk", variable=self.milk2, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")   
        self.saladCheck = Checkbutton(self, text="Salad", variable=self.salad, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")
        self.pizzaCheck = Checkbutton(self, text="Pizza", variable=self.pizza, \
                                    onvalue=1, offvalue=0, style="BG.TCheckbutton",\
                                    state = "normal")
        self.milkCheck2.place(relx=0.25, rely=0.655)
        self.saladCheck.place(relx=0.5, rely=0.655)
        self.pizzaCheck.place(relx=0.75, rely=0.655)

        # add image for each for foods
        milkOrImage = Image.open("milk.gif")
        milkResized = milkOrImage.resize((100, 100))
        milkResized = ImageTk.PhotoImage(milkResized)
        self.milkPanel = Label(self, image=milkResized)
        self.milkPanel.image = milkResized
        self.milkPanel.place(relx=0.25, rely=0.095)
        self.milkDesc = Label(self, text="Milk 240mL  $1.00", font='times 12')
        self.milkDesc.place(relx=0.25, rely=0.25)
        # Add image of soup
        soupOrImage = Image.open("soup.gif")
        soupResized = soupOrImage.resize((100, 100))
        soupResized = ImageTk.PhotoImage(soupResized)
        self.soupPanel = Label(self, image=soupResized)
        self.soupPanel.image = soupResized
        self.soupPanel.place(relx=0.5, rely=0.095)
        self.soupDesc = Label(self, text="Soup 240mL  $2.00", font='times 12')
        self.soupDesc.place(relx=0.5, rely=0.25)
        # Add image of bread
        breadOrImage = Image.open("bread.gif")
        breadResized = breadOrImage.resize((100, 100))
        breadResized = ImageTk.PhotoImage(breadResized)
        self.breadPanel = Label(self, image=breadResized)
        self.breadPanel.image = breadResized
        self.breadPanel.place(relx=0.75, rely=0.095)
        self.breadDesc = Label(self, text="Bread 2 slices  $0.50", font='times 12')
        self.breadDesc.place(relx=0.75, rely=0.25)

        # Add image of juice
        juiceOrImage = Image.open("juice.gif")
        juiceResized = juiceOrImage.resize((100, 100))
        juiceResized = ImageTk.PhotoImage(juiceResized)
        self.juicePanel = Label(self, image=juiceResized)
        self.juicePanel.image = juiceResized
        self.juicePanel.place(relx=0.25, rely=0.395)
        self.juiceDesc = Label(self, text="Orange juice 240mL  $1.00", font='times 12') 
        self.juiceDesc.place(relx=0.22, rely=0.55)

        # Add image of chicken food
        chickOrImage = Image.open("chicken.gif")
        chickResized = chickOrImage.resize((100, 100))
        chickResized = ImageTk.PhotoImage(chickResized)
        self.chickPanel = Label(self, image=chickResized)
        self.chickPanel.image = chickResized
        self.chickPanel.place(relx=0.5, rely=0.395)
        self.chickDesc = Label(self, text="Sesame ginger chicken  $10.00", font='times 12')
        self.chickDesc.place(relx=0.455, rely=0.55)

        # Add image of beef food
        beefOrImage = Image.open("beef.gif")
        beefResized = beefOrImage.resize((100, 100))
        beefResized = ImageTk.PhotoImage(beefResized)
        self.beefPanel = Label(self, image=beefResized)
        self.beefPanel.image = beefResized
        self.beefPanel.place(relx=0.75, rely=0.395)
        self.beefDesc = Label(self, text="Beef noodle  $12.50", font='times 12')
        self.beefDesc.place(relx=0.75, rely=0.55)

        # Add milk image again for dinner
        milkOrImage = Image.open("milk.gif")
        milkResized = milkOrImage.resize((100, 100))
        milkResized = ImageTk.PhotoImage(milkResized)
        self.milkPanel = Label(self, image=milkResized)
        self.milkPanel.image = milkResized
        self.milkPanel.place(relx=0.25, rely=0.695)
        self.milkDesc = Label(self, text="Night milk 240mL  $1.00", font='times 12')
        self.milkDesc.place(relx=0.22, rely=0.85)

        # Add salad image again for dinner
        saladOrImage = Image.open("salad.gif")
        saladResized = saladOrImage.resize((100, 100))
        saladResized = ImageTk.PhotoImage(saladResized)
        self.saladPanel = Label(self, image=saladResized)
        self.saladPanel.image = saladResized
        self.saladPanel.place(relx=0.5, rely=0.695)
        self.saladDesc = Label(self, text="Salad 4oz  $3.00", font='times 12')
        self.saladDesc.place(relx=0.5, rely=0.85)

        # Add pizza image again for dinner
        pizzaOrImage = Image.open("pizza.gif")
        pizzaResized = pizzaOrImage.resize((100, 100))  # resize the image
        pizzaResized = ImageTk.PhotoImage(pizzaResized)
        self.pizzaPanel = Label(self, image=pizzaResized)
        self.pizzaPanel.image = pizzaResized
        self.pizzaPanel.place(relx=0.75, rely=0.695)
        self.pizzaDesc = Label(self, text="Pizza 1 slice  $2.00", font='times 12')
        self.pizzaDesc.place(relx=0.75, rely=0.85)
        
        # Create clock Label
        self.clockLabel = Label(self)
        self.clockLabel.place(relx=0.7, rely=0.005)
        self.clock()

    def orderTime(self):
        """The order rules: only order today meal
        1. Before 07:00, the user may order breakfast, lunch, and dinner.
        2. Before 11:00, the user may order lunch, and dinner.
        3. Before 17:00, the user may order dinner. """
        # chech current time, and set order time limit.
        self.current_time = datetime.strftime(datetime.now(),"%H:%M:%S")
        self.breOrderTime = "07:00:00"
        self.lunOrderTime = "11:00:00"
        self.dinOrderTime = "17:00:00"
        # After 07:00, the user may not order breakfast.
        if self.current_time > self.breOrderTime:
            self.milkCheck["state"] = "disabled"
            self.soupCheck["state"] = "disabled"
            self.breadCheck["state"] = "disabled"
        # After 11:00, the user may not order lunch.    
        if self.current_time > self.lunOrderTime:
            self.juiceCheck["state"] = "disabled"
            self.chickCheck["state"] = "disabled"
            self.beefCheck["state"] = "disabled"            
        # After 17:00, the user may not order dinner.
        if self.current_time > self.dinOrderTime:
            self.milkCheck2["state"] = "disabled"
            self.saladCheck["state"] = "disabled"
            self.pizzaCheck["state"] = "disabled"                   
    
    
    def clock(self):
        """Make a digit clock to show current time."""
        t = time.asctime(time.localtime(time.time())) # current time
        if t != '':
            self.clockLabel.config(text=t, font='times 16') # set clock style
        self.after(100, self.clock)  # after() method to update the current time every second
        
    def mealVisit(self):
        """Display a messagebox with ordered information and confirm the breakfast order."""
        sum = 0
        message = ""
        if self.milk.get() == 0 and self.soup.get() == 0 and self.bread.get() == 0 and \
            self.juice.get() == 0 and self.chicken.get() == 0 and self.beef.get() == 0 and \
            self.milk2.get() == 0 and self.salad.get() == 0 and self.pizza.get() == 0:            
            message = "No food ordered!" 
            tkinter.messagebox.showinfo(title="Customer Order", message = message)
        else:        
            self.orders = {}            
            if self.milk.get() == 1 or self.soup.get() == 1 or self.bread.get() == 1:
                """Breakfast meal order"""
                (message, sum) = self.checkBreakfast(message, sum)                      
                tkinter.messagebox.showinfo("Visit order", message = message)
               
            if  self.juice.get() == 1 or self.chicken.get() == 1 or self.beef.get() == 1:
                """Lunch meal order"""
                sum = 0
                message = ""
                (message, sum) = self.checkLunch(message, sum)                       
                tkinter.messagebox.showinfo("Visit order", message = message)

            if  self.milk2.get() == 1 or self.salad.get() == 1 or self.pizza.get() == 1:
                """Dinner meal order"""
                sum = 0
                message = ""
                (message, sum) = self.checkDinner(message, sum)                       
                tkinter.messagebox.showinfo("Visit order", message = message)
            self.showSummary()

    def checkBreakfast(self, message, sum):
        """If the user order breakfast, related info to store in self.orders."""
        message += "Your breakfast order list:\n\n"    # store message of in messagebox
        if self.milk.get() == 1:
            message += "Milk: a cup (240mL), $1.00\n\n"
            sum += 1.00
            self.orders["Milk"] = 1.00
        if self.soup.get() == 1:
            message += "Soup: a cup (240mL), $2.00\n\n"    
            sum += 2.00
            self.orders["Soup"] = 2.00
        if self.bread.get() == 1:
            message += "White bread: 2 slices, $0.50\n\n"
            sum += 0.50
            self.orders["Bread"] = 0.50
        message += "The breakfast order is $ %0.2f"%sum +"." 
        return (message, sum)

    def checkLunch(self, message, sum):
        """If the user order lunch, related info to store in self.orders."""
        message += "Your lunch order list:\n\n"  # store message of in messagebox
        if self.juice.get() == 1:
            message += "Juice: a cup (240mL), $1.00\n\n"
            sum += 1.00
            self.orders["Juice"] = 1.00
        if self.chicken.get() == 1:
            message += "Chicken food, $10.00\n\n"    
            sum += 10.00
            self.orders["Chicken food"] = 10.00
        if self.beef.get() == 1:
            message += "Beef food: $12.50\n\n"
            sum += 12.50
            self.orders["Beef food"] = 12.50
        message += "The lunch order is $ %0.2f"%sum +"."
        return (message, sum)
    
    def checkDinner(self, message, sum):
        """If the user order dinner, related info to store in self.orders."""
        message += "Your dinner order list:\n\n"   # store message of in messagebox
        if self.milk2.get() == 1:
            message += "Night milk: a cup (240mL), $1.00\n\n"
            sum += 1.00
            self.orders["Night milk"] = 1.00
        if self.salad.get() == 1:
            message += "salad: 4 oz, $3.00\n\n"    
            sum += 3.00
            self.orders["Salad"] = 3.00
        if self.pizza.get() == 1:
            message += "Pizza: 1 slice, $2.00\n\n"
            sum += 2.00
            self.orders["Pizza"] = 2.00
        message += "The dinner order is $ %0.2f"%sum +"." 
        return (message, sum)

    def showSummary(self):
        """List the order and total price in messagebox"""
        if self.orders != {}:
            sum = 0
            message = ""
            for (key, value) in self.orders.items():
                sum += value
                message += key + " : $%0.2f"%value + '\n'
            message += "The total order is $ %0.2f"%sum +"."
            tkinter.messagebox.showinfo("Total order", message = message)  

    def openWindow(self):
        """Open third window. Before that, the system will report the order information again."""
        message = ""
        sum = 0
        self.checkBreakfast(message, sum)
        self.checkLunch(message, sum)
        self.checkDinner(message, sum)
        self.showSummary()
        
        if self.orders == {}:
            message = "No food ordered!" 
            tkinter.messagebox.showinfo(title="Customer Order", message = message)
        else:
            self.orderBtn["state"] = "disabled"
            newWindow2 = PlaceOrder(self)
            newWindow2.grab_set()

    def reactivePlaceOrderBtn(self, event):
        self.orderBtn["state"] = "normal"

class PlaceOrder(tk.Toplevel):
    """The third window for order meal."""
    def __init__(self, master=None):
        super().__init__(master, bg="light blue")
        self.master = master
        self.title("Place Order")  # name the window
        self.geometry("400x300") # set the window size        
        self.ROOM_NUMBER = ["101", "102", "103", "104", "105", "201", "202", "203", "204", "205"] # set number range
        self.createWidget2()
 
    def createWidget2(self):
        """Create widgets."""
        # Format the style of label.
        style = ttk.Style()
        style.configure("BG.TLabel", foreground="black", background="light blue")       
        
        # Create a label of name
        self.nameLabel = Label(self, text="Username", font=("times new man", 16), background="light blue")
        self.nameLabel.pack(pady=3)
        # Create an Entry for a user to input name.
        self.username = tk.StringVar()   # StringVar() is a variable of a string.
        self.nameEntry = Entry(self, textvariable=self.username,font=("times new man", 16), width=15)        
        self.nameEntry.pack(pady=10)  # pady set the distence at y direction between widgets
        # Create a label of room number
        self.roomLabel = Label(self, text="Room Number", font=("times new man", 16), \
                                background="light blue")
        self.roomLabel.pack(pady=10)
        # Create an Entry for a user to input room number.
        self.roomNum = tk.StringVar()
        self.roomEntry = Entry(self, textvariable=self.roomNum, font=("times new man", 16), width=15)
        self.roomEntry.pack(pady=10)
        
        # Create a button to make sure the user will place order.
        self.orderBtn = Button(self, text="Place Order", command=self.place_Order)
        self.orderBtn.bind("<Destroy>", self.master.reactivePlaceOrderBtn)
        self.orderBtn.pack(pady=15)

    def place_Order(self):
        """Validate the user input correctly"""            
        self.username = self.nameEntry.get()  # get the username from Entry
        self.roomNum =self.roomEntry.get()    # get room number from Entry         

        if self.username == "" or self.roomNum == "":
            tkinter.messagebox.showerror("Error", "You don't enter your name or room number. Try it again.")
        if self.roomNum in self.ROOM_NUMBER:            
            if self.username != "":                
                result = tkinter.messagebox.askquestion("Confirm your information", f"You name is {self.username}. You room number is {self.roomNum}.\nAre you sure?")
                if result == "yes":
                    tkinter.messagebox.showinfo("Message", "You have successfully ordered your meal.")
                    self.destroy()  # third window will destroy after the user orders. 
                    now = datetime.now()   # get the time
                    today = date.today()
                    todayDate = f"{today.year}" + f"{today.month}" + f"{today.day}"                    
                    current_time = now.strftime("%H%M%S") # format the time
                    # name a file name
                    fName = self.username + "_" + self.roomNum + "_" + todayDate + "_" + current_time
                    # open a file and store a dictionaty to a file
                    userFile = open(f"{fName}.pkl", "wb")
                    pickle.dump(self.master.orders, userFile)
                    userFile.close()             
               
        if self.roomNum not in self.ROOM_NUMBER and self.username != "":
            tkinter.messagebox.askretrycancel("Warning", "Your room number is incorrect. Tri it again.") 
    
# mainloop, runs infinitely
app = Welcome()
app.mainloop()              


