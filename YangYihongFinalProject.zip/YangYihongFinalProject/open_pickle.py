"""
open_pickle.py    Yihong Yang
This program is used to open the files stored patient' meal order information.
"""
import pickle
userFile = open("Tom_203_20211214_111910.pkl", "rb") # Open *.pkl file, "read" style.clear
output = pickle.load(userFile)  # Load file content to "output".
print(output)    # Show the output in terminal field.
userFile.close()   # Close the file.