# This will import all the widgets
# and modules which are available in
# tkinter and ttk module
from tkinter import ttk
from tkinter import *
from tkinter.ttk import *
import tkinter.messagebox 

# import tkinter.font as font
 
#root = Tk()
class MealOrder(Toplevel):
    #import tkinter.messagebox 
    def __init__(self, master = None):

        super().__init__(master, bg="light blue")
        self.master = master
        self.title("Meal Order Page")
        self.geometry("800x400")
        #self.pack()
        self.createWidget()
         
        #super().__init__(master = master)
        #self.title("Meal Order Page")
        #self.geometry("800x400")

    def createWidget(self):
        """create widget"""
        style = ttk.Style()
        style.configure("BG.TLabel", foreground="black", background="light blue")
        style.configure("BG.TCheckbutton", foreground="black", background="light blue")
        style.configure("BG.TButton", foreground="black", background="light blue")

        self.label = Label(self, text ="Meal Order", font=("times new man", 20), style="BG.TLabel")
        self.label.pack()
        # build "Breakfast" label
        self.breadLabel = Label(self, text="Breakfast", font=("times new man", 16), style="BG.TLabel")
        self.breadLabel.place(x=0, y=100)
        
        # Three Checkbuttons for breakfast(milk, soup, bread)
        self.milk = tkinter.IntVar()
        self.soup = tkinter.IntVar()
        self.bread = tkinter.IntVar()

        self.milkCheck = Checkbutton(self, text="Milk", variable=self.milk, onvalue=1, offvalue=0, style="BG.TCheckbutton")   
        self.soupCheck = Checkbutton(self, text="Soup", variable=self.soup, onvalue=1, offvalue=0, style="BG.TCheckbutton")
        self.breadCheck = Checkbutton(self, text="Bread", variable=self.bread, onvalue=1, offvalue=0, style="BG.TCheckbutton")
        self.milkCheck.place(x=200, y=105)
        self.soupCheck.place(x=350, y=105)
        self.breadCheck.place(x=500, y=105)

        self.btnConfirm1 = Button(self, text="Confirm", command=self.breConfirm, style="BG.TButton")
        self.btnConfirm1.place(x=650, y=105)
        
        # Lunch choice
        # self.lunchLabel = Label(self, text="Lunch")
        # self.lunchLabel.grid(row=4, column=0)
        
    def breConfirm(self):
        """Display a messagebox with ordered information and confirm the order."""
        sum = 0
        message = ""
        if  self.milk.get() == 0 and self.soup.get() == 0 and self.bread.get() == 0:
            message = "No food ordered!" 
            tkinter.messagebox.showinfo(title="Customer Order", message = message)
        else:
            if self.milk.get() == 1:
                message += "Milk: a cup (240mL), $1.00\n\n"
                sum += 1.00
            if self.soup.get() == 1:
                message += "Soup: a cup (240mL), $1.00\n\n"    
                sum += 1.00
            if self.bread.get() == 1:
                message += "White bread: 2 slices, 0.50\n\n"
                sum += 0.50                       
            message += "The total order is $ %0.2f"%sum +".\n\nDo you order you meal?"        
            tkinter.messagebox.askquestion("Confirm order", message = message)
        

 
# creates a Tk() object
root = Tk()
root.title("ABH Hospital Online Meal Order Service")
 
# sets the geometry of
# main root window
root.geometry("800x760")

welcome = Text(root, width=100, height=1, bg="light blue",font=("times new man",30))
#introduction.grid(row=0, columnspan=4)
welcome.pack() 
welcome.insert(1.0,"Welcome to ABH Hospital meal order page.")

# insert a photo to mainwindow
photo = PhotoImage(file="hospital.gif")  
imagLabel = Label(root, image=photo)
imagLabel.pack()                    
 
#label = Label(master, text ="This is the main window")
#label.pack(side = TOP, pady = 10)

introduction = Text(root, width=100, height=5, bg="light blue", font=("times new man",20))
introduction.pack() 
introduction.insert(1.0, "You may order your breakfast, lunch and diner.\n"+
                    "Easy click to choose your meal.") 

 
# a button widget which will
# open a new window on button click
#myFont = font.Font(size=14)
btn = Button(root, text ="Continue Your Oder")

# Following line will bind click event
# On any click left / right button
# of mouse a new window will be opened
btn.bind("<Button>",
         lambda e: MealOrder(root), root.destroy)
 
btn.pack(side=BOTTOM, pady = 10)
 
# mainloop, runs infinitely
mainloop()